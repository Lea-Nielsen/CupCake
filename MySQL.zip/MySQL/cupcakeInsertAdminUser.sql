USE cupcake;

INSERT INTO `user`(username, `password`, balance, email, role)
VALUES
("admin", "admin", 10000.00, "admin@test.dk", "admin");