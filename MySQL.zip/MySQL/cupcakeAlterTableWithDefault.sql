USE cupcake;

ALTER TABLE `user` ADD `role` varchar(45) NOT NULL DEFAULT "customer";