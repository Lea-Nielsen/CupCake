select * from `user`;
-- select * from bottoms;

-- update `user` SET balance = 150.00 WHERE username = "morten";

SELECT order_id FROM orders ORDER BY order_id;

select orders.order_id, u_username, qty, cupcakename, cupcakeprice, totalprice, ordertotalprice, orderDate
from orders 
join orderdetails on orders.order_id = orderdetails.order_id
join cupcake on cupcake.id = orderdetails.c_id
where u_username = "morten"
order by order_id ASC, orderDate ASC, qty ASC, cupcakename ASC;

INSERT INTO `user`(username, `password`, balance, email, role)
VALUES
("admin", "admin", 10000.00, "admin@test.dk", "admin");

-- UPDATE `user`, orders SET balance = (balance - orders.ordertotalprice) WHERE username = "morten";

insert into orders (u_username, ordertotalprice, orderdate) values ("morten", 10.00, '2018-09-23');
insert into cupcake (cupcakename, cupcakeprice, t_toppingname, b_bottomname) values ("Chocolate with Chocolate", 10.00, "Chocolate", "Chocolate");
insert into orderdetails (order_id, c_id, qty, totalprice) values (1, 1, 2, 20.00);
insert into cupcake (cupcakename, cupcakeprice, t_toppingname, b_bottomname) values ("Almond with Orange", 15.00, "Orange", "Almond");
insert into orderdetails (order_id, c_id, qty, totalprice) values (1, 2, 1, 15.00);

-- select order_id from orders where u_username = "morten";

-- SELECT orders.order_id, u_username, qty, cupcakename, cupcakeprice, totalprice, ordertotalprice, orderDate
-- FROM orders 
-- JOIN orderdetails ON orders.order_id = orderdetails.order_id
-- JOIN cupcake ON cupcake.id = orderdetails.c_id
-- WHERE orders.order_id = 1
-- ORDER BY qty ASC, cupcakename ASC;

-- SELECT orders.order_id, u_username, qty, cupcakename, cupcakeprice, totalprice, ordertotalprice, orderDate FROM orders JOIN orderdetails ON orders.order_id = orderdetails.order_id JOIN cupcake ON cupcake.id = orderdetails.c_id WHERE orders.order_id = 1 ORDER BY qty ASC, cupcakename ASC;
